package http://hl7.org/fhir/us/davinci-deqm-r4/ImplementationGuide/ig;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class Profilemeasuredeqm {

}
